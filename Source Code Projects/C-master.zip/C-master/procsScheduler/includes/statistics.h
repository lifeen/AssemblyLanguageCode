#ifndef STATISTICSHEADER
#define STATISTICSHEADER

void statistics(process **processes, int procCount, int finishTime, char *fname);


#endif 