int main(int argc, char const *argv[])
{
	int a;
	printf("ajdfoiwejdf\n");
	scanf("%d", &a);
	printf("a = %d\n", a);
	return 0;
}