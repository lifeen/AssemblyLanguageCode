# Assembly  
Assembly for intel 8086 microprocessor family 

## Contents
- Scramble Encryption : Reverse the binary order of the index of each character and print the output on the new order.
- ID Password check : searches for an id in the stored IDs and then verify its password.
