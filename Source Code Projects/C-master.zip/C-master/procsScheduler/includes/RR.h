#ifndef RRHEADER
#define RRHEADER

int RunRR(process **processes, int procCount, int quantumTime);


#endif 