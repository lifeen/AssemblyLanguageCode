/*Programmer Chase Singhofen
date 10/25/2016
Specifications:in class work*/

#include<stdio.h>
#include<stdlib.h>
main() {

	int num = 1, avg = 0;
	for (i = 1; avg <= 0; i++) {
		printf("enter four numbers %i\n", num);
		sum = sum + avg;
	}
	system("pause");
}
//end main