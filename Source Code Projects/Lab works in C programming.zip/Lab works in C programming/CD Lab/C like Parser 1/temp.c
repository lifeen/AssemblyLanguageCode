main () {
	int a;
	char b, c;
	a = 10;
}