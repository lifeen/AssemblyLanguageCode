# Programando en Ensamblador(Intel 8086)

## Información de los registros 

<table>
<tr>
	<th>Nombre del Registro</th>
	<th>Uso</th>
</tr>
<tr>
	<td>AX</td>
	<td>Propósito General</td>
</tr>
<tr>
	<td>BX</td>
	<td>Propósito General</td>
</tr>
<tr>
	<td>CX</td>
	<td>Propósito General</td>
</tr>
<tr>
	<td>DX</td>
	<td>Propósito General</td>
</tr>
<tr>
	<td>SI</td>
	<td>Registro Índice</td>
</tr>
<tr>
	<td>DI</td>
	<td>Registro Índice</td>
</tr>
<tr>
	<td>SS</td>
	<td>Segmento de Pila</td>
</tr>
<tr>
	<td>SP</td>
	<td>Apuntador de Pila</td>
</tr>
<tr>
	<td>DS</td>
	<td>Segmento de Datos</td>
</tr>
<tr>
	<td>ES</td>
	<td>Segmento Extra</td>
</tr>
</table> 
