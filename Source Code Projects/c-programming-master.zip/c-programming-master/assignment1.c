#include<stdib.h>
#include<stdio.h>

main() {

	printf("Hello World!");

		system("pause");

}