#ifndef FCFSHEADER
#define FCFSHEADER

int RunFCFS(process **processes, int procCount);

#endif 