#include <stdio.h>
int main() {
    int a, b = 20, c = 30;
    a = b * c;
    return 0;
}