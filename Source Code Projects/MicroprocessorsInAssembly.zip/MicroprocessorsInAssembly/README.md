# Microprocessors
8085,8086,AVR
