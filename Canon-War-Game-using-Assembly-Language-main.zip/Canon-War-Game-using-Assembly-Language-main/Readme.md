# Canon-War-Game-using-Assembly-Language

There is only one masm file which needs to be run.
The rest of them are text files.

All the files have been commented for your ease. Furthermore you may also add further comments if you may. 

For better understanding of the scenerio, refer to "Requirements.md" and "Report.pdf".

As it was a group project, the links of Githubs of my members can be found below:

Ayesha Marriyam = 
Shoaib Murtaza =

For further queries contact me at : chhxnshah@gmail.com
