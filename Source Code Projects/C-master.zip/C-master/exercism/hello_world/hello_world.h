#ifndef HELLO_WORLD_H
#define HELLO_WORLD_H

const char *hello(void);

#endif
