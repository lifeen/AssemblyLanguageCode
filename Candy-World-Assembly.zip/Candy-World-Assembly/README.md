# Candy World
------------------------------------------------------------------

<== This project is made in Assembly Language using Masm32 ==>
* Mainly focused on windows.inc library.

------------------------------------------------------------------

Files in Project:-

1. Assets (Folder) => includes all the images used in project.
2. CandyWorld.asm => All of the source code is written in this file.
3. bitblt.inc => This file contains all prototypes, macros, and definintions.
4. rsrc.rc => this file contains paths of resource files (e.g. images,icon,cursor) and their declaration.
5. makeit.bat => this file is used to compile the source code.
** .OBJ files are automatically generated when code is compile.

---------------------------------------------------------------------------------------------------------
Here are screenshots of the game:

![screenshot1](https://user-images.githubusercontent.com/20368350/29095684-3f9d84f6-7cab-11e7-848e-06580f6ea15e.PNG)





![screenshot2](https://user-images.githubusercontent.com/20368350/29095685-3fe10988-7cab-11e7-9d91-c85ab88c177c.PNG)
