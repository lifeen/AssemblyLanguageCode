int main(int argc, char const *argv[])
{
	int a;
	WRITE("ajdfoiwejdf\n");
	READ("%d", &a);
	WRITE("a = %d\n", a);
	return 0;
}