/*Programmer Chase Singhofe
Date 10/8/16
Specifications: While-loops*/

#include<stdio.h>
#include<stdlib.h>

main() {

	int count = 1;

	while (count <= 10) {
		printf("%i", count);
		count = count + 1;
	}

		system("pause");

	}