#include <stdio.h>
#include <stdlib.h>
 

void temp(double a, double b, double c, double d);

int main(void)
{
	double(a) (b) (c);



 degree(a, b, c );
 {
	int celsius, fahrenheit;

	printf("\nEnter temp in celsius:");
	scanf_s("%i", &celsius);

	fahrenheit = (celsius * 1.8) + 32;
	printf("\n temp in fahrenheit :%i ", fahrenheit);


	printf("\nEnter temp in fahrenheit:");
	scanf_s("%i", &fahrenheit);

	celsius = (fahrenheit - 32) / 1.8;
	printf("\n temp in celsius :%i ", celsius);

	system("pause");
}


