/*Programmer - chase
Date- 9/1/2016
Hello World- First Program
*/



#include<stdlib.h>
#include<stdio.h>

main() {

	printf("Hello World!\n");

	system("pause");

}