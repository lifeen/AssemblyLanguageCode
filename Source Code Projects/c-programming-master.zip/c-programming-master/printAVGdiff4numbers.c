/*Programmer Chase Singhofen
date 10/25/2016
Specifications:Enter 4 numbers and print average of those numbers*/

#include<stdio.h>
#include<stdlib.h>
main() {

	int i, j, k, l;
	printf("enter 1 number\n");
	scanf_s("%i", &i);
	for (i = 0; i <= 4; i++)
		for (j = 0; j < 3; j++)
			printf("%i", j);
	{
		
	}

	{
		printf("enter 2 numbers\n");//only need 2 "for loops". triangle problem

	}/*
	for (k = 0; k < 2; k++)
	{
		printf("enter 3 numbers\n");

	}

	for (l = 0; l < 1; l++)
	{
		printf("enter 4 numbers\n");

	}*/
	system("pause");
}
//end main