# Loop Unrolling Program

'''
for _ in range(5):
    print("Witing a loop")
'''

# unrolled loop - but how do i do this programatically?
if __name__ == "__main__":
    print("Witing a loop")
    print("Witing a loop")
    print("Witing a loop")
    print("Witing a loop")
    print("Witing a loop")
