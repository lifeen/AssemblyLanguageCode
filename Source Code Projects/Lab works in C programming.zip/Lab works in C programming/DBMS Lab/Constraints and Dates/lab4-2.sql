create table Department2 (
	deptNo number(8),
	deptName varchar(20) unique,
	location varchar(20),
	primary key (deptNo)
);