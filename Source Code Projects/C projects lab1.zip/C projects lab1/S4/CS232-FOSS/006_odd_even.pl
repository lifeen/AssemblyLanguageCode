#! /usr/bin/perl
# Even or odd 06
print("Enter a number: ");
$num = <>;
if($num%2 == 0){
	print("Even\n");
}
else{
	print("Odd\n");
}
