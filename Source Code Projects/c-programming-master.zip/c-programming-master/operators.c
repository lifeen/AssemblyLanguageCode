/*Programmer Chase Singhofen
date:09/27/2016
Comparitive Operators*/

//Programmer Directives: Comparitive Operators

#include<stdio.h>
#include<stdlib.h>
//main function
main() {
	//variable declarations
	int num1 = 0, num2 = 0;
	//user prompt
	printf("Enter the two numbers \n");
	scanf_s("%i %i", &num1, &num2);
	printf("You entered %i, %i\n", num1, num2);
	{
		if (num1, num2);
		printf("Number 1 is greater,\n");
	}
/*else if (num1 > num2);
	{
		else
	}
		printf("\nBoth mubers are the same!\n");*/


system("pause");

}
	
