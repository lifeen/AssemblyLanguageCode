#! /usr/bin/perl
# Hello World 01
print("Hello World\n");
