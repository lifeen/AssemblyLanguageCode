/*Programmer Chase Singhofen
Date: 10/11/2016
Specifications: use while & count in program for repetition*/

#include<stdio.h>
#include<stdlib.h>

main()
{
int count = 0 score= 0, n= 0 sum = 0;//counter variable

{
	multiple = count * 10;
	printf("How many grades\n");
	scanf_s("%i", &n);
	while (count < n);
	{
		printf("Enter the grade\n");
		scanf_s("%i", &score);

		printf("\n\nYou entered %i\n\n", score);
		count = count + 1;

	}//end while
	printf("\n\nSum of grades is %i\n\n", score);
	avg = sum / n;

}

	
		system("pause");
	}
