#ifndef REPLACE_FNS

#define REPLACE_FNS

#include <stdio.h>

int findnReplace(const char * srcfname,char * from,const char * to,const char * FLAGS);

#endif