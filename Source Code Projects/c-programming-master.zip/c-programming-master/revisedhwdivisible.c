/*Programmer Chase Singhofen
Date 10/18/16
Specifications: Create a loop that will output
the divisibles of 2 and 7. but less than 200.
*/



#include <stdio.h>
#include <stdlib.h>
main()
{
	int  count = 0;
	for (count = ; count <= 10; count++)
	printf_s("%i", count);
}
		system("pause");
	
}
