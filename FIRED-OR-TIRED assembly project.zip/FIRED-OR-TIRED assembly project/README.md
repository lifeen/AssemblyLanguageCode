<p align="center">
  <a href="https://github.com/AbdallahHemdan/FIRED-OR-TIRED" rel="noopener">
    
  ![Component 1](https://user-images.githubusercontent.com/40190772/87235570-91d3ff80-c3dd-11ea-9e82-027219ed44ab.png)

  
  </a>
</p>

<div align="center">
  
[![GitHub issues](https://img.shields.io/github/issues/AbdallahHemdan/FIRED-OR-TIRED)](https://github.com/AbdallahHemdan/FIRED-OR-TIRED/issues)
[![GitHub forks](https://img.shields.io/github/forks/AbdallahHemdan/FIRED-OR-TIRED)](https://github.com/AbdallahHemdan/FIRED-OR-TIRED/network)
[![GitHub stars](https://img.shields.io/github/stars/AbdallahHemdan/FIRED-OR-TIRED)](https://github.com/AbdallahHemdan/FIRED-OR-TIRED/stargazers)
[![GitHub license](https://img.shields.io/github/license/AbdallahHemdan/FIRED-OR-TIRED)](https://github.com/AbdallahHemdan/FIRED-OR-TIRED/blob/master/LICENSE)

</div>

## 🔫 Fired or Tired
> Fired or Tired is a 2 player assembly X86 shooting game that each player has a gun and can use his gun in horizontal line to shot the other player, every player has the ability to move right or left or even jump with the existence of Gravity 🌎     

> There are 3 Power-Ups that will appear in periodic time that gives the player who takes it first its advantage either increase the health by one, shot a fire with double the power, or shield that save you from the enemy's shot 


## 📷 ScreenShots 

![1](https://user-images.githubusercontent.com/40190772/70800361-b7037f80-1db4-11ea-8913-318ea7d12f45.PNG)

<hr />

![6](https://user-images.githubusercontent.com/40190772/70800356-b5d25280-1db4-11ea-9e8a-b883c3630d87.PNG)

<hr />

![7](https://user-images.githubusercontent.com/40190772/70800359-b66ae900-1db4-11ea-805c-1c33354b7919.PNG)

<hr />

![5](https://user-images.githubusercontent.com/40190772/70800355-b5d25280-1db4-11ea-98fb-f7775c450ba9.png)

<hr />

![8](https://user-images.githubusercontent.com/40190772/70800360-b66ae900-1db4-11ea-9720-1a891e0bf667.png)

<hr />

![3](https://user-images.githubusercontent.com/40190772/70800363-b79c1600-1db4-11ea-91ab-704e85c28296.png)


## 📽 GIF Demo
![output1 (1)](https://user-images.githubusercontent.com/40190772/70800517-211c2480-1db5-11ea-979f-2b199a9915df.gif)
![output2](https://user-images.githubusercontent.com/40190772/70800518-211c2480-1db5-11ea-868b-d6f198856bea.gif)
