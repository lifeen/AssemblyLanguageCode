insert into Department2 values ('1', 'Bogo', 'NY');

insert into Employee values ('010', 'Carter', 'M', '900000', null, '4');
insert into Employee values ('002', 'Hersh', 'N', '650000', 'Address 2', '6');