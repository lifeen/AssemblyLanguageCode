#include<stdio.h>
#include<stdlib.h>
main()
{

	int i, j;//variables 
	for (i = 1; i <= 5; i++)//the i<=5 determines how many rows will print.

	{
		for (j = 1; j <= i; j++)//inner for loop controls how many times the * gets printed or whatever you want to be
							//be printed in the printf statment.object-oriented programming language that's designed to be portable and workable on as many 
		{
			printf("3");
		}
		printf("\n");
	}
	system("pause");
}