# Game_Of_The_Life
the game of the life written on assembly TASM x16bit with direct access to video memory
