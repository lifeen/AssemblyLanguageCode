#include<stdlib.h>
#include<stdio.h>

main() {

	printf("Hello World!\n");

	system("pause");

}