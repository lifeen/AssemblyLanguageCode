# CSE-Labs
B.Tech CSE lab programs under KTU Syllabus 2017-2021 https://ktu.edu.in/
