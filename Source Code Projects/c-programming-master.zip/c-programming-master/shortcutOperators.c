/*Programmer Chase Singhofen
date 10/18/2016
Specifications: shortcut operators*/

#include<stdio.h>
#include<stdlib.h>
//main function
main()
{
	scanf_s("find the small of several integers");
	int 2;



	system("pause");

}