#! /usr/bin/perl
# Count upto ten 03
for($i=1; $i<=10; $i++) {
	print ($i," ");
}
print ("\n");
