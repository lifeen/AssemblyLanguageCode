# README #

### What is this repository for? ###

* Effective and simple repository to learn Assembly
* Version 1.0

### Contribution guidelines ###

### Who do I talk to? ###

* [It's me, Mario =)](https://github.com/pedruino)
