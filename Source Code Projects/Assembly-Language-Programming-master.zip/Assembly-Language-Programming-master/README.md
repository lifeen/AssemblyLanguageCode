## Assembly Language Programming
Using 8086 assembly language and MASM as assembler

### Environment Setup
1. Install Dosbox
For Ubuntu: apt-get install dosdox
2. Download the following pakage from the link https://drive.google.com/drive/u/0/folders/0B1DiPkxLHBZHTWVQVVNlYVptU3M and extract it
(For simplicity, rename it to masm)
You are done. To test:

For Ubuntu and other linux based OS, follow https://bit.ly/3nQVOmw for a guided installation

For other OS, just the installation process will be bit different, rest assembling and executing through dosbox will be essentially the same and can be followed at https://bit.ly/3nQVOmw

