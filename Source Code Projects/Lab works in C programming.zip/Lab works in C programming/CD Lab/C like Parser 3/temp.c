main () {
	int x;
	char y;
	int p;
	x = p;
	x = p + x * p;
	if (x == p) {
		y = x;
	} else {
		y = p;
	}
}
