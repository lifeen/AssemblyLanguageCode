# Constant Propagation Program

if __name__ == "__main__":
    x = 10
    y = x + 45
    z = y + 4
    print(f"The value of z = {z}")
