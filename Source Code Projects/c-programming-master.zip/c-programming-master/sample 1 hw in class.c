/*Programmer: Chase Singhofen
Date:
Specification: Array�s Introduction
*/

//preprocessors
#include <stdio.h>
#include <stdlib.h>
#define SIZE 10//defined constant.
//main function
main() {

	int numbers[SIZE], search, count = 0;
	
	for (int i = 0; i < SIZE; i++) {
		printf("enter the number you are searching for");
		scanf_s("%i", &search);
	}
	for (int i = 0; i < SIZE; i++) {

		if (num[1] == search)
			count++;

	}//end search for
	if (count !=0)
		pri
		//to be continued.....


	//end main function
	system("pause");
}
