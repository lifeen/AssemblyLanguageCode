/*Programmer Chase Singhofen
Date: 9/28/2016
Specifications: Convert Temps
*/

#include<stdio.h>
#include<stdlib.h>

main() //Main Function
{
	double a = 5.0, b = 9.0, c = -32.0, result;
	result = (a / b) * (c);





	system("Pause");
}//End Main