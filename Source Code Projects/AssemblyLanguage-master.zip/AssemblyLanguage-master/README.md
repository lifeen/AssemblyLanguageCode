# AssemblyLanguage
Run Assembly Code with c/c++ using XCDE in Mac


Assalam O Alaikum,

This is simple Demo to Run Assembly Code in XCODE on MAC. Simply call an Assembly Function from C/C++, Objective-C or Swift File and Assembly Code will return the SUM of TWO Numbers after moving it in different registers.

Jzak Allah, 
Akhzar Nazir
