# SnakeXenia.asm
Snake Xenia is a game we used to play in Mobiles. I have tried to implement the game on console by using MASM and Assembely Language following Irvine32 library.
To run this file , you will need
Microsoft Visual Studio 2010 or later.
You will need Irvine32 lirary download it and Copy it in C:\
and copy the path and paste in the Include Library box in Visual Studio
This game is made using Microsoft Visual Studio 2010 but it can be run on any version of Micrsft Visual Studio.
For information abput setting up MASM assembeler in Visual Studio see the tutorial.
2015: https://www.youtube.com/watch?v=9e1ER2o83N0
2010: https://www.youtube.com/watch?v=EubI_8Ek3fk

Thank You.
