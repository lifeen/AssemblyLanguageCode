# Hash algorithms

* sdbm
* djb2
* xor8 (8 bit)
* adler_32 (32 bit)
* crc32 (32 bit)
