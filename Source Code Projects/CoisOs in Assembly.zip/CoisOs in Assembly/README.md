# CoisOS
16-bit Operating System written in NASM

## Building:
To build, just run `make`.
### Requirements:
* NASM  (to assemble the source)
* node.js (to generate the filesystem)
